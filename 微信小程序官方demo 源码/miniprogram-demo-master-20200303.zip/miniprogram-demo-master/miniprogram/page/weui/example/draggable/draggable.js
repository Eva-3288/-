Page({
    data: {
        list: [
            1, 2, 3
        ]
    }
})