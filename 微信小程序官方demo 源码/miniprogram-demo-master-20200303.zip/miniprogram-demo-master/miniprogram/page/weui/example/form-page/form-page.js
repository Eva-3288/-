Component({
    data: {},
    methods: {}
});