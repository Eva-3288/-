Page({
  data: {
    iconList: [
      {
        icon: "add-friends",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "add",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "add2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "album",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "arrow",
        color: 'black',
        size: 12,
        name: ''
      },
      {
        icon: "at",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "back",
        color: 'black',
        size: 12,
        name: ''
      },
      {
        icon: "back2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "bellring-off",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "bellring-on",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "camera",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "cellphone",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "clip",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "close",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "close2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "comment",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "contacts",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "copy",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "delete-on",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "delete",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "discover",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "display",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "done",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "done2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "download",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "email",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "error",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "eyes-off",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "eyes-on",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "folder",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "group-detail",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "help",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "home",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "imac",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "info",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "keyboard",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "like",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "link",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "location",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "lock",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "max-window",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "me",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "mike",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "mike2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "mobile-contacts",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "more",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "more2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "mosaic",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "music-off",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "music",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "note",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "pad",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "pause",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "pencil",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "photo-wall",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "play",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "play2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "previous",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "previous2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "qr-code",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "refresh",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "report-problem",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "search",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "sending",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "setting",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "share",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "shop",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "star",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "sticker",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "tag",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "text",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "time",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "transfer-text",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "transfer2",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "translate",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "tv",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "video-call",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "voice",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "volume-down",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "volume-off",
        color: 'black',
        size: 25,
        name: ''
      },
      {
        icon: "volume-up",
        color: 'black',
        size: 25,
        name: ''
      },
    ]
  }
});